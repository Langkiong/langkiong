<div class="d-block p-4">
	<center>
		<!-- IN ARTICLE ADS -->
	</center>
</div>