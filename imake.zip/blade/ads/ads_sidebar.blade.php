<div class="d-block p-4">
	<center>
		<!-- SIDEBAR ADS -->
	</center>
</div>