<div class="d-block p-4">
	<center>
		<!-- TOP BANNER ADS -->
	</center>
</div>